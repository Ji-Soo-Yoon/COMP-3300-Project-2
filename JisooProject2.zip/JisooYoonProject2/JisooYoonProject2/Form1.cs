﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace JisooYoonProject2
{
    public partial class Form1 : Form
    {
        private Random rng = new Random();

        // Letters and dictionary
        private List<char> chosenLetters = new List<char>();
        private HashSet<string> dictionary = new HashSet<string>();
        private HashSet<string> usedWords = new HashSet<string>();

        // Scoring
        private int totalScore = 0;

        // Round tracking
        private List<GameRound> allRounds = new List<GameRound>();
        private GameRound currentRound;
        private DateTime roundStartTime;
        private int roundCounter = 0;

        // Timer (default 1 minute)
        private int timeLeft = 60;

        // High Scores
        private List<HighScoreEntry> highScores = new List<HighScoreEntry>();
        private readonly string highScoreFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "highscores.json");

        public Form1()
        {
            InitializeComponent();
            LoadDictionary();
            DiagnoseDictionary();
            LoadHighScores();
            DisplayRandomLetters();
        }

        // Dictionary
        private void LoadDictionary()
        {
            try
            {
                string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "dictionary.json");
                string json = File.ReadAllText(path, Encoding.UTF8);





                var groups = JsonSerializer.Deserialize<List<DictionaryGroup>>(json)
                             ?? new List<DictionaryGroup>();

                dictionary = new HashSet<string>(
                    groups
                        .Where(g => g.words != null)
                        .SelectMany(g => g.words)
                        .Select(w => w.Trim().ToLowerInvariant())
                );

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading dictionary: " + ex.Message);
                dictionary = new HashSet<string>();
            }
        }


        // High Scores
        private void LoadHighScores()
        {
            try
            {
                if (File.Exists(highScoreFile))
                {
                    string json = File.ReadAllText(highScoreFile);
                    highScores = JsonSerializer.Deserialize<List<HighScoreEntry>>(json) ?? new List<HighScoreEntry>();
                }
            }
            catch
            {
                highScores = new List<HighScoreEntry>();
            }
        }

        private void SaveHighScores()
        {
            try
            {
                string json = JsonSerializer.Serialize(highScores);
                File.WriteAllText(highScoreFile, json);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving high scores: " + ex.Message);
            }
        }

        private void AddHighScore(string playerName, int score, TimeSpan time)
        {
            highScores.Add(new HighScoreEntry { Name = playerName, Score = score, Time = time });
            SaveHighScores();
        }

        private void viewHighScoresItem_Click(object sender, EventArgs e)
        {
            var sorted = highScores.OrderByDescending(h => h.Score).ToList();
            ShowHighScoreBoard(sorted, "High Score Board (Score)");
        }

        private void viewHighScoresByTimeItem_Click(object sender, EventArgs e)
        {
            var sorted = highScores.OrderBy(h => h.Time).ThenByDescending(h => h.Score).ToList();
            ShowHighScoreBoard(sorted, "High Score Board (Time + Score)");
        }

        private void resetHighScoresItem_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show("Reset the high score board? This cannot be undone.", "Confirm Reset",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (confirm == DialogResult.Yes)
            {
                highScores.Clear();
                try
                {
                    if (File.Exists(highScoreFile)) File.Delete(highScoreFile);
                }
                catch { /* ignore */ }
                MessageBox.Show("High score board has been reset.");
            }
        }

        private void ShowHighScoreBoard(List<HighScoreEntry> entries, string title)
        {
            if (entries.Count == 0)
            {
                MessageBox.Show("No high scores yet.", title);
                return;
            }

            string display = $"{title}:\n\n";
            int rank = 1;
            foreach (var entry in entries)
            {
                display += $"{rank}. {entry.Name} - {entry.Score} pts - {FormatTime(entry.Time)}\n";
                rank++;
            }
            MessageBox.Show(display, title);
        }

        private static string FormatTime(TimeSpan ts)
        {
            return ts.TotalHours >= 1 ? ts.ToString(@"hh\:mm\:ss") : ts.ToString(@"mm\:ss");
        }

        // Export Stats (CSV)
        private void exportStatsItem_Click(object sender, EventArgs e)
        {
            if (allRounds.Count == 0)
            {
                MessageBox.Show("No rounds played yet. Stats cannot be exported.");
                return;
            }

            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";
                sfd.Title = "Export Stats";
                sfd.FileName = "TextTwistStats.csv";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (StreamWriter sw = new StreamWriter(sfd.FileName))
                        {
                            // CSV header
                            sw.WriteLine("Round,Word,Valid,Points,GameTimeSeconds,Reason");

                            foreach (var round in allRounds)
                            {
                                foreach (var entry in round.Entries)
                                {
                                    // Write clean CSV row; escape commas in Reason
                                    string reason = entry.Reason?.Replace(",", ";") ?? "";
                                    sw.WriteLine($"{round.RoundNumber},{entry.Word},{entry.IsValid},{entry.Points},{Math.Round(entry.GameTime.TotalSeconds)},{reason}");
                                }
                            }
                        }
                        MessageBox.Show("Stats exported successfully!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error exporting stats: " + ex.Message);
                    }
                }
            }
        }

        // Rounds & Letters
        private void StartNewRound()
        {
            roundCounter++;
            roundStartTime = DateTime.Now;

            currentRound = new GameRound
            {
                RoundNumber = roundCounter,
                StartTime = roundStartTime
            };
            allRounds.Add(currentRound);

            usedWords.Clear();

            lblTimer.Text = $"Time Left: {timeLeft}s";
            gameTimer.Stop();
            gameTimer.Start();
        }

        private void DisplayRandomLetters()
        {
            List<char> bag = new List<char>();
            bag.AddRange(Enumerable.Repeat('e', 11));
            bag.AddRange(Enumerable.Repeat('t', 9));
            bag.AddRange(Enumerable.Repeat('o', 8));
            bag.AddRange(Enumerable.Repeat('a', 6));
            bag.AddRange(Enumerable.Repeat('i', 6));
            bag.AddRange(Enumerable.Repeat('n', 6));
            bag.AddRange(Enumerable.Repeat('s', 6));
            bag.AddRange(Enumerable.Repeat('h', 5));
            bag.AddRange(Enumerable.Repeat('r', 5));
            bag.AddRange(Enumerable.Repeat('l', 4));
            bag.AddRange(Enumerable.Repeat('d', 3));
            bag.AddRange(Enumerable.Repeat('u', 3));
            bag.AddRange(Enumerable.Repeat('w', 3));
            bag.AddRange(Enumerable.Repeat('y', 3));
            bag.AddRange(Enumerable.Repeat('b', 2));
            bag.AddRange(Enumerable.Repeat('c', 2));
            bag.AddRange(Enumerable.Repeat('f', 2));
            bag.AddRange(Enumerable.Repeat('g', 2));
            bag.AddRange(Enumerable.Repeat('m', 2));
            bag.AddRange(Enumerable.Repeat('p', 2));
            bag.AddRange(Enumerable.Repeat('v', 2));
            bag.AddRange(Enumerable.Repeat('j', 1));
            bag.AddRange(Enumerable.Repeat('k', 1));
            bag.AddRange(Enumerable.Repeat('q', 1));
            bag.AddRange(Enumerable.Repeat('x', 1));
            bag.AddRange(Enumerable.Repeat('z', 1));

            chosenLetters.Clear();
            for (int i = 0; i < 7; i++)
            {
                int index = rng.Next(bag.Count);
                chosenLetters.Add(bag[index]);
            }

            for (int i = 0; i < 7; i++)
            {
                letterButtons[i].Text = chosenLetters[i].ToString();
                letterButtons[i].Enabled = true;
                letterButtons[i].BackColor = SystemColors.Control;
            }

            this.Text = "Text Twist by Yoon";
            StartNewRound();
        }

        // Word submission
        private void btnSubmitWord_Click(object sender, EventArgs e)
        {
            string word = txtWordEntry.Text.Trim().ToLower();
            TimeSpan gameTime = DateTime.Now - roundStartTime;

            if (string.IsNullOrEmpty(word))
            {
                MessageBox.Show("Please enter a word.");
                return;
            }

            if (word.Length < 3)
            {
                TrackWord(word, false, 0, gameTime, "Too short (<3 letters)");
                MessageBox.Show("Word must be at least 3 letters long.");
                return;
            }

            if (!ConsumeLettersIfAvailable(word))
            {
                TrackWord(word, false, 0, gameTime, "No Point");
                MessageBox.Show("Letter check failed");
                return;
            }

            if (!dictionary.Contains(word))
            {
                TrackWord(word, false, 0, gameTime, "No Point");
                MessageBox.Show("Dictionary check failed");
                return;
            }

            if (usedWords.Contains(word))
            {
                TrackWord(word, false, 0, gameTime, "Already used");
                MessageBox.Show("Word already used. No points awarded.");
                return;
            }

            int points = CalculatePoints(word.Length);
            totalScore += points;
            usedWords.Add(word);

            TrackWord(word, true, points, gameTime, null);
            lstWords.Items.Add($"{word} (+{points} pts)");
            txtWordEntry.Clear();

            MessageBox.Show($"Valid word! You earned {points} points.\nTotal Score: {totalScore}");
        }

        // Consume letters (from enabled buttons)
        private bool ConsumeLettersIfAvailable(string word)
        {
            var availability = new List<Button>(letterButtons);

            foreach (char c in word)
            {
                var match = availability.FirstOrDefault(
                    b => b.Enabled && b.Text.Equals(c.ToString(), StringComparison.OrdinalIgnoreCase)
                );

                if (match == null)
                {
                    // Letter not available among current buttons
                    return false;
                }

                // Remove this button from temporary availability so duplicates are handled correctly
                availability.Remove(match);
            }

            // Do NOT disable buttons permanently here
            // Letters remain reusable for multiple words (TextTwist-style)
            return true;
        }


        private int CalculatePoints(int length)
        {
            return length switch
            {
                3 => 90,
                4 => 160,
                5 => 250,
                6 => 360,
                7 => 490,
                _ => 0
            };
        }

        private void TrackWord(string word, bool isValid, int points, TimeSpan gameTime, string reason)
        {
            if (currentRound == null) StartNewRound();
            currentRound.Entries.Add(new WordEntry
            {
                Word = word,
                IsValid = isValid,
                Points = points,
                GameTime = gameTime,
                Reason = reason
            });
        }

        // Round end
        private void EndRound()
        {
            if (currentRound == null) return;

            var validWords = currentRound.entriesValid();
            int roundScore = validWords.Sum(e => e.Points);

            string summary = $"Round {currentRound.RoundNumber} Summary:\n\n";
            foreach (var entry in validWords)
            {
                summary += $"{entry.Word} - {entry.Points} pts\n";
            }
            summary += $"\nTotal Round Score: {roundScore}\nOverall Score: {totalScore}";

            MessageBox.Show(summary, "Round Results");

            // Prompt to record high score for this round (treat round as game)
            string playerName = PromptForName("Enter your name for the High Score Board:", "High Score");
            if (!string.IsNullOrWhiteSpace(playerName))
            {
                TimeSpan totalTimeForThisRound = DateTime.Now - currentRound.StartTime;
                AddHighScore(playerName.Trim(), totalScore, totalTimeForThisRound);
            }
        }

        private void btnEndRound_Click(object sender, EventArgs e)
        {
            gameTimer.Stop();
            EndRound();
        }

        // Timer menu handlers
        private void oneMinuteItem_Click(object sender, EventArgs e)
        {
            timeLeft = 60;
            lblTimer.Text = "Time Left: 60s";
        }

        private void twoMinutesItem_Click(object sender, EventArgs e)
        {
            timeLeft = 120;
            lblTimer.Text = "Time Left: 120s";
        }

        private void threeMinutesItem_Click(object sender, EventArgs e)
        {
            timeLeft = 180;
            lblTimer.Text = "Time Left: 180s";
        }

        // Countdown tick
        private void gameTimer_Tick(object sender, EventArgs e)
        {
            if (timeLeft > 0)
            {
                timeLeft--;
                lblTimer.Text = $"Time Left: {timeLeft}s";
            }
            else
            {
                gameTimer.Stop();
                EndRound();
                MessageBox.Show("Time's up! Round ended.");
            }
        }

        // Twist feature
        private void btnTwist_Click(object sender, EventArgs e)
        {
            var enabledButtons = letterButtons.Where(b => b.Enabled).ToList();
            var enabledTexts = enabledButtons.Select(b => b.Text).ToList();

            enabledTexts = enabledTexts.OrderBy(_ => rng.Next()).ToList();

            for (int i = 0; i < enabledButtons.Count; i++)
            {
                enabledButtons[i].Text = enabledTexts[i];
                enabledButtons[i].BackColor = SystemColors.Control;
            }

            foreach (var btn in letterButtons.Where(b => !b.Enabled))
            {
                btn.BackColor = Color.LightGray;
            }

            chosenLetters.Clear();
            foreach (var btn in letterButtons)
            {
                if (!string.IsNullOrWhiteSpace(btn.Text))
                    chosenLetters.Add(btn.Text[0]);
            }
        }

        // New Game
        private void newGameItem_Click(object sender, EventArgs e)
        {
            // Optional: save current to high scores
            if (currentRound != null && currentRound.Entries.Any(e => e.IsValid))
            {
                var saveCurrent = MessageBox.Show("Save current progress to High Scores before starting a new game?",
                    "Save Progress", MessageBoxButtons.YesNo);
                if (saveCurrent == DialogResult.Yes)
                {
                    string playerName = PromptForName("Enter your name for the High Score Board:", "High Score");
                    if (!string.IsNullOrWhiteSpace(playerName))
                    {
                        TimeSpan timeForThisRound = DateTime.Now - currentRound.StartTime;
                        AddHighScore(playerName.Trim(), totalScore, timeForThisRound);
                    }
                }
            }

            gameTimer.Stop();

            totalScore = 0;
            lstWords.Items.Clear();

            allRounds.Clear();
            currentRound = null;
            roundCounter = 0;

            timeLeft = 60; // reset default
            lblTimer.Text = "Time Left: 60s";

            DisplayRandomLetters();

            MessageBox.Show("New game started!");
        }

        // Exit
        private void exitItem_Click(object sender, EventArgs e)
        {
            if (currentRound != null && currentRound.Entries.Any(e => e.IsValid))
            {
                var saveCurrent = MessageBox.Show("Save current progress to High Scores before exiting?", "Save Progress",
                    MessageBoxButtons.YesNo);
                if (saveCurrent == DialogResult.Yes)
                {
                    string playerName = PromptForName("Enter your name for the High Score Board:", "High Score");
                    if (!string.IsNullOrWhiteSpace(playerName))
                    {
                        TimeSpan timeForThisRound = DateTime.Now - currentRound.StartTime;
                        AddHighScore(playerName.Trim(), totalScore, timeForThisRound);
                    }
                }
            }

            Application.Exit();
        }

        // Prompt helper
        private string PromptForName(string text, string caption)
        {
            using (Form prompt = new Form())
            {
                prompt.Width = 360;
                prompt.Height = 160;
                prompt.FormBorderStyle = FormBorderStyle.FixedDialog;
                prompt.Text = caption;
                prompt.StartPosition = FormStartPosition.CenterParent;

                Label textLabel = new Label() { Left = 20, Top = 20, Width = 300, Text = text };
                TextBox inputBox = new TextBox() { Left = 20, Top = 50, Width = 300 };
                Button confirmation = new Button() { Text = "OK", Left = 160, Width = 80, Top = 85, DialogResult = DialogResult.OK };
                Button cancel = new Button() { Text = "Cancel", Left = 240, Width = 80, Top = 85, DialogResult = DialogResult.Cancel };

                confirmation.Click += (sender, e) => { prompt.Close(); };
                cancel.Click += (sender, e) => { prompt.Close(); };

                prompt.Controls.Add(textLabel);
                prompt.Controls.Add(inputBox);
                prompt.Controls.Add(confirmation);
                prompt.Controls.Add(cancel);
                prompt.AcceptButton = confirmation;
                prompt.CancelButton = cancel;

                return prompt.ShowDialog(this) == DialogResult.OK ? inputBox.Text : string.Empty;
            }
        }

        private void DiagnoseDictionary()
        {
            Console.WriteLine("=== Starting Dictionary Diagnostics ===");

            int total = dictionary.Count;
            int suspiciousCount = 0;

            foreach (var word in dictionary)
            {
                bool suspicious = false;

                foreach (char c in word)
                {
                    // Non-ASCII
                    if (c > 127)
                    {
                        Console.WriteLine($"[Unicode >127] '{word}' contains U+{(int)c:X4}");
                        suspicious = true;
                    }

                    // Zero-width space
                    if (c == '\u200B')
                    {
                        Console.WriteLine($"[Zero-width space] '{word}' contains U+200B");
                        suspicious = true;
                    }

                    // Non-breaking space
                    if (c == '\u00A0')
                    {
                        Console.WriteLine($"[NBSP] '{word}' contains U+00A0");
                        suspicious = true;
                    }

                    // Soft hyphen
                    if (c == '\u00AD')
                    {
                        Console.WriteLine($"[Soft hyphen] '{word}' contains U+00AD");
                        suspicious = true;
                    }

                    // Control characters
                    if (char.IsControl(c))
                    {
                        Console.WriteLine($"[Control char] '{word}' contains control U+{(int)c:X4}");
                        suspicious = true;
                    }
                }

                if (suspicious)
                    suspiciousCount++;
            }

            Console.WriteLine($"=== Diagnostics Complete ===");
            Console.WriteLine($"Total words: {total}");
            Console.WriteLine($"Suspicious words: {suspiciousCount}");
        }

    }

    // Models
    public class WordEntry
    {
        public string Word { get; set; }
        public bool IsValid { get; set; }
        public int Points { get; set; }
        public TimeSpan GameTime { get; set; }
        public string? Reason { get; set; }
    }

    public class GameRound
    {
        public int RoundNumber { get; set; }
        public List<WordEntry> Entries { get; set; } = new List<WordEntry>();
        public DateTime StartTime { get; set; }

        // Convenience: valid entries list
        public List<WordEntry> entriesValid()
        {
            return Entries.Where(e => e.IsValid).ToList();
        }
    }

    public class HighScoreEntry
    {
        public string Name { get; set; }
        public int Score { get; set; }
        public TimeSpan Time { get; set; }
    }

    public class DictionaryGroup
    {
        public string letter { get; set; }
        public List<string> words { get; set; }
    }

}
