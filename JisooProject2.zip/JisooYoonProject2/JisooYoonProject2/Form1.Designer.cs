﻿namespace JisooYoonProject2
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // Controls
        private System.Windows.Forms.TextBox txtWordEntry;
        private System.Windows.Forms.Button btnSubmitWord;
        private System.Windows.Forms.ListBox lstWords;
        private System.Windows.Forms.Button[] letterButtons;
        private System.Windows.Forms.Button btnEndRound;
        private System.Windows.Forms.Button btnTwist;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gameMenu;
        private System.Windows.Forms.ToolStripMenuItem timerMenu;
        private System.Windows.Forms.ToolStripMenuItem oneMinuteItem;
        private System.Windows.Forms.ToolStripMenuItem twoMinutesItem;
        private System.Windows.Forms.ToolStripMenuItem threeMinutesItem;
        private System.Windows.Forms.ToolStripMenuItem newGameItem;
        private System.Windows.Forms.ToolStripMenuItem exitItem;
        private System.Windows.Forms.ToolStripMenuItem viewHighScoresItem;
        private System.Windows.Forms.ToolStripMenuItem viewHighScoresByTimeItem;
        private System.Windows.Forms.ToolStripMenuItem resetHighScoresItem;
        private System.Windows.Forms.ToolStripMenuItem exportStatsItem;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Timer gameTimer;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.txtWordEntry = new System.Windows.Forms.TextBox();
            this.btnSubmitWord = new System.Windows.Forms.Button();
            this.lstWords = new System.Windows.Forms.ListBox();
            this.btnEndRound = new System.Windows.Forms.Button();
            this.btnTwist = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.timerMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.oneMinuteItem = new System.Windows.Forms.ToolStripMenuItem();
            this.twoMinutesItem = new System.Windows.Forms.ToolStripMenuItem();
            this.threeMinutesItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHighScoresItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHighScoresByTimeItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetHighScoresItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportStatsItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lblTimer = new System.Windows.Forms.Label();
            this.gameTimer = new System.Windows.Forms.Timer(this.components);

            this.letterButtons = new System.Windows.Forms.Button[7];
            this.SuspendLayout();

            // txtWordEntry
            this.txtWordEntry.Location = new System.Drawing.Point(50, 80);
            this.txtWordEntry.Name = "txtWordEntry";
            this.txtWordEntry.Size = new System.Drawing.Size(200, 23);
            this.txtWordEntry.TabIndex = 0;

            // btnSubmitWord
            this.btnSubmitWord.Location = new System.Drawing.Point(260, 80);
            this.btnSubmitWord.Name = "btnSubmitWord";
            this.btnSubmitWord.Size = new System.Drawing.Size(75, 23);
            this.btnSubmitWord.TabIndex = 1;
            this.btnSubmitWord.Text = "Submit";
            this.btnSubmitWord.UseVisualStyleBackColor = true;
            this.btnSubmitWord.Click += new System.EventHandler(this.btnSubmitWord_Click);

            // lstWords
            this.lstWords.FormattingEnabled = true;
            this.lstWords.ItemHeight = 15;
            this.lstWords.Location = new System.Drawing.Point(50, 120);
            this.lstWords.Name = "lstWords";
            this.lstWords.Size = new System.Drawing.Size(285, 200);
            this.lstWords.TabIndex = 2;

            // btnEndRound
            this.btnEndRound.Location = new System.Drawing.Point(350, 80);
            this.btnEndRound.Name = "btnEndRound";
            this.btnEndRound.Size = new System.Drawing.Size(90, 23);
            this.btnEndRound.TabIndex = 3;
            this.btnEndRound.Text = "End Round";
            this.btnEndRound.UseVisualStyleBackColor = true;
            this.btnEndRound.Click += new System.EventHandler(this.btnEndRound_Click);

            // btnTwist
            this.btnTwist.Location = new System.Drawing.Point(350, 30);
            this.btnTwist.Name = "btnTwist";
            this.btnTwist.Size = new System.Drawing.Size(90, 40);
            this.btnTwist.TabIndex = 4;
            this.btnTwist.Text = "Twist";
            this.btnTwist.UseVisualStyleBackColor = true;
            this.btnTwist.Click += new System.EventHandler(this.btnTwist_Click);

            // MenuStrip
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.gameMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(480, 24);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";

            this.gameMenu.Text = "Game";
            this.gameMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.timerMenu, this.newGameItem, this.exitItem,
                this.viewHighScoresItem, this.viewHighScoresByTimeItem,
                this.resetHighScoresItem, this.exportStatsItem});

            this.timerMenu.Text = "Timer";
            this.timerMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.oneMinuteItem, this.twoMinutesItem, this.threeMinutesItem});

            this.oneMinuteItem.Text = "1 Minute";
            this.oneMinuteItem.Click += new System.EventHandler(this.oneMinuteItem_Click);

            this.twoMinutesItem.Text = "2 Minutes";
            this.twoMinutesItem.Click += new System.EventHandler(this.twoMinutesItem_Click);

            this.threeMinutesItem.Text = "3 Minutes";
            this.threeMinutesItem.Click += new System.EventHandler(this.threeMinutesItem_Click);

            this.newGameItem.Text = "New Game";
            this.newGameItem.Click += new System.EventHandler(this.newGameItem_Click);

            this.exitItem.Text = "Exit";
            this.exitItem.Click += new System.EventHandler(this.exitItem_Click);

            this.viewHighScoresItem.Text = "View High Scores";
            this.viewHighScoresItem.Click += new System.EventHandler(this.viewHighScoresItem_Click);

            this.viewHighScoresByTimeItem.Text = "View High Scores (Time + Score)";
            this.viewHighScoresByTimeItem.Click += new System.EventHandler(this.viewHighScoresByTimeItem_Click);

            this.resetHighScoresItem.Text = "Reset High Scores";
            this.resetHighScoresItem.Click += new System.EventHandler(this.resetHighScoresItem_Click);

            this.exportStatsItem.Text = "Export Stats";
            this.exportStatsItem.Click += new System.EventHandler(this.exportStatsItem_Click);

            // lblTimer
            this.lblTimer.Location = new System.Drawing.Point(50, 330);
            this.lblTimer.Size = new System.Drawing.Size(200, 23);
            this.lblTimer.Text = "Time Left: 60s"; // default
            this.lblTimer.Name = "lblTimer";

            // gameTimer
            this.gameTimer.Interval = 1000; // 1 second
            this.gameTimer.Tick += new System.EventHandler(this.gameTimer_Tick);

            // letterButtons
            for (int i = 0; i < 7; i++)
            {
                this.letterButtons[i] = new System.Windows.Forms.Button();
                this.letterButtons[i].Location = new System.Drawing.Point(50 + (i * 45), 30);
                this.letterButtons[i].Name = "btnLetter" + i;
                this.letterButtons[i].Size = new System.Drawing.Size(40, 40);
                this.letterButtons[i].TabIndex = 6 + i;
                this.letterButtons[i].UseVisualStyleBackColor = true;
                this.Controls.Add(this.letterButtons[i]);
            }

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 380);
            this.Controls.Add(this.txtWordEntry);
            this.Controls.Add(this.btnSubmitWord);
            this.Controls.Add(this.lstWords);
            this.Controls.Add(this.btnEndRound);
            this.Controls.Add(this.btnTwist);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Text Twist by Yoon";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion
    }
}
